from libvht import vhtmodule
from vht.configuration import Configuration

mod = vhtmodule.VHTModule()
cfg = Configuration()
