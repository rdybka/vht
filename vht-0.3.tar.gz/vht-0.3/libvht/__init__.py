from libvht import vhtmodule


def mod():
    return vhtmodule.VHTModule()
